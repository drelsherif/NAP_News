export { InstitutionalSpotlightBlock } from './AllBlocks';
// Legacy alias for backwards compatibility
export { InstitutionalSpotlightBlock as NorthwellSpotlightBlock } from './AllBlocks';
