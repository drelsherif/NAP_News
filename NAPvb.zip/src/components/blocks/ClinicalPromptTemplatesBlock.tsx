export { ClinicalPromptTemplatesBlock } from './AllBlocks';
